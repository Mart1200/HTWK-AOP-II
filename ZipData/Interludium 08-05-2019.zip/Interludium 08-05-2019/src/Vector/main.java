package Vector;

public class main {

	public static void main(String[] args) {
		Vector v1 = new Vector(3);
		Vector v2 = new Vector(3);
		
		
		System.out.println(v1);
		System.out.println(v2);
		System.out.println(v1.winkelZw(v2));

	}

}
